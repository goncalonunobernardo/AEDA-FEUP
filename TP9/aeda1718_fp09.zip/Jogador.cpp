#include "Jogador.h"


void Jogador::adicionaAposta(const Aposta & ap)
{
	// TODO
}

unsigned Jogador::apostasNoNumero(unsigned num) const
{
	// TODO
	unsigned count = 0;
	return count;
}


tabHAposta Jogador::apostasPremiadas(const tabHInt & sorteio) const
{
	// TODO
	tabHAposta money;
	return money;
}
