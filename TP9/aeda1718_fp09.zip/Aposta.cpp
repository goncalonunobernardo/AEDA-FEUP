#include "Aposta.h"
#include <iostream>
#include <sstream>

using namespace std;

bool Aposta::contem(unsigned num) const
{
	// TODO
	return true;
}


void Aposta::geraAposta(const vector<unsigned> & valores, unsigned n)
{
	// TODO
}


unsigned Aposta::calculaCertos(const tabHInt & sorteio) const
{
	// TODO
	unsigned certos = 0;
	return certos;
}




